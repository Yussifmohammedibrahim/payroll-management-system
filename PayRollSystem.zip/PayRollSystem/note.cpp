/*



.........................
	Instantiator
........................
+number_of_emps
+new_taxes
+tax_history[]
........................

.......................



.........................
	Emp
.........................
+emp_name
+emp_id
+hoursWorked
+tax
+bonus
-salary
-hourSalary
-totalHour
........................
+calcSalary();
+setHoursWorked();
+editInfo()
+sumBonuses()
........................



.........................
	GetSetters
........................

........................
+setHour(double hour);
+getHour(Emp.name emp_name): double;
+getMaxHour(): double
+setTax(double percentage); 
+setEmp();
+getEmp(Emp.name emp_name): Emp
+getAllEmps(): Emp[]
.......................




.......................
	AppRunner
......................

......................
+runApp();
+editEmp();
+removeEmp();
+findEmp();
......................
*/
