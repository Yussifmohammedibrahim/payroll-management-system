
  
/*
	CLASS DIAGRAM FOR "emp Class"
	.........................
		Emp
	.........................
	-emp_name: string
	-emp_id: string
	-hoursWorked: double
	-tax: double
	-bonus: double[]
	-bonus_top: int
	-salary: double
	-hourSalary: double
	-totalHour: double
	-calcSalary();
	
	-tax_calculated: bool
	-salary_calculated: bool
	........................
	+setHoursWorked();
	+editInfo()
	+sumBonuses()
	+setInfo();
	+getString()
	+getDouble();
	+alert(string msg, bool new_line, bool line_brk);
	+lineBrk()
	........................
*/

#include <iostream>
#include <fstream>
#include "garbage.h"
using namespace std;


struct Report
{
	string name;
	string id;
	double hours_worked;
	double tax;
	double salary;
};


class Emp
{
	public:
		void writeToFile(string save_as_name)
		{
			string file_name = save_as_name + ".txt";
			ofstream fileOpener;
			fileOpener.open(file_name.c_str());
			
			
			fileOpener << "*************************************************" << endl;
			fileOpener << "Name:............................." << this->report->name << endl;
			fileOpener << "Id:..............................." << this->report->id << endl;
			fileOpener << "Hours Worked:......................" << this->report->hours_worked << endl;
			fileOpener << "Tax:..............................." << this->report->tax << endl;
			fileOpener << "Bonus:............................." << this->sum_of_bonus << endl;
			fileOpener << "Salary:............................" << this->report->salary << endl;
			fileOpener << "***************************************************" << endl;
			fileOpener << "       [+] REPORT IS SAVED TO FILE         " << endl;
			fileOpener << "````````````````````````````````````````````````````" << endl;
			
			
			cout << "***************************************************" << endl;
			cout  << "       [+] REPORT IS SAVED TO FILE         " << endl;
			cout  << "````````````````````````````````````````````````````" << endl;
			
			fileOpener.close();
			
		};
	
		void saveReport(string save_as_name)
		{
			this->writeToFile(save_as_name);
		};
		
		void showReport()
		{
			this->calTax(this->salary, this->tax);
			this->calSalary();
			
			string *name = new string;
			*name = this->emp_name;
			
			string *id = new string;
			*id = this->emp_id;
			
			
			double *hours_worked = new double;
			*hours_worked = this->total_hours_worked;
			
			
			double *tax = new double;
			*tax = this->tax;
			
			
			double *salary = new double;
			*salary = this->salary;
			
			
			cout << endl;
			cout << "......................................." << endl;
			
			this->alert("[+] ..........REPORT..............", true, false);
			
			cout << "name:.........................." << *name << endl;
			
			cout << "id:............................" << *id << endl;
			
			cout << "hours worked:.................." << *hours_worked << endl;
			
			cout << "tax:..........................." << *tax << endl;
			
			cout << "Bonus:........................." << this->sum_of_bonus << endl;
			
			cout << "Salary:........................$" << *salary << endl;
			
			cout << "........................................" << endl;
			
			this->report = new Report;
			this->report->name = *name;
			this->report->id = *id;
			this->report->hours_worked = *hours_worked;
			this->report->tax = *tax;
			this->report->salary = *salary;
			
			string save_as = *name + "_" + *id;
			this->writeToFile(save_as);
			
			this->garb.freeString(name);
			this->garb.freeString(id);
			this->garb.freeDouble(hours_worked);
			this->garb.freeDouble(tax);
			this->garb.freeDouble(salary);

			return;
		};
		
		void sumAllBonus()
		{
			for(int i=0; i<=this->bonus_top; i++)
			{
				this->sum_of_bonus += this->bounues[i];
			};
			
		};
		
		void calSalary()
		{
			
			if(this->salary_claculated == false)
			{
				for(int i=0; i<=this->bonus_top; i++)
				{
					this->salary += this->bounues[i];
				};
				
				if(this->total_hours_worked == 0)
				{
					do
					{
				
						this->alert("[+] hours worked can not be zero (0)", false, false);
						cout << "" << endl;
						this->total_hours_worked = this->getDouble("[+] Enter hours worked");
						
					}while(this->total_hours_worked == 0);
					this->sumAllBonus();
				};
				
				this->salary += this->total_hours_worked * this->pay_per_hour;
				
				this->salary = this->calTax(this->salary, this->tax);
				
				cout << endl;
				alert("[+] SALARY ALREADY CALCULATED. PLEASE CONSIDER SETTING NEW VALUES FOR THE EMP*", false, true);
				cout << endl;
				
				cout << this->salary << endl;
				
				this->salary_claculated = true;
				return;
			};
			
			cout << "salary already calculated" << endl;
		};
		
		double calTax(double total_salary, double tax)
		{
			double value = 0;
			
			if(this->tax_calculated == false)
			{
					
				if(this->total_hours_worked == 0)
				{
					this->total_hours_worked = this->getDouble("[+] Enter hours worked");
					this->calSalary();
				};
				
				value += (total_salary / 100) * tax;
				
				this->tax_calculated = true;
				return value;
			};
			
			cout << "Tax already calculated" << endl;
		};
		
		void setInfo()
		{
			string *name = new string;
			*name = getString("[+] Enter emp name");
			string *id = new string;
			*id = getString("[+] Enter emp id");
			double *pay_per_hour = new double;
			*pay_per_hour = getDouble("[+] Enter pay per hour");
			
			double *tax = new double;
			*tax = getDouble("[+] Enter tax");
			
			
			this->emp_name = *name;
			this->emp_id = *id;
			this->pay_per_hour = *pay_per_hour;
			this->tax = *tax;
			
			alert("[+] THE NEW INFORMATON IS SET ", true, true);
			
			this->garb.freeDouble(tax);
			this->garb.freeDouble(pay_per_hour);
			this->garb.freeString(name);
			this->garb.freeString(id);
			
			return;
		};
		
		void setTax()
		{
			double *new_tax = new double;
			*new_tax = getDouble("[+] Enter set tax");
			
			this->tax = *new_tax;
			alert("[+] New Tax is set", true, true);
			
			this->tax_calculated = true;
			
			this->garb.freeDouble(new_tax);
			return;
		};
		
		void setHourPay()
		{
			double *hour_pay = new double;
			*hour_pay = getDouble("[+] Enter hour pay");
			this->pay_per_hour = *hour_pay;
			
			alert("[+] Hour pay is set", true, true);
			
			delete hour_pay;
		};
		
		void setBonuses()
		{
			if(this->bonus_top != 2)
			{
				double *bonus_value = new double;
				this->bonus_top += 1;
				
				*bonus_value = getDouble("[+] Enter bonus value");
				this->bounues[this->bonus_top] = *bonus_value;
				
				
				alert("[+] Bonus is set", true, true);
				delete bonus_value;
				return;
			};
			
			alert("[+] Bonus Slot is full", true, true);
			return;
		};
		
		string getString(string msg)
		{
			string value = "";
			
			alert(msg, false, true);
			cin >> value;
			
			return value;
		};
		
		double getDouble(string msg)
		{
			double value = 0;
			
			alert(msg, false, true);
			cin >> value;
			
			return value;
		};
		
		void alert(string msg, bool new_line, bool line_brk)
		{
			if(line_brk)
			{
				this->lineBrk();
			};
			
			if(new_line)
			{
				cout << msg << endl;
			}else
			{
				printf("%s: ", msg.c_str());
			};
		};
		
		void lineBrk()
		{
			cout << "................" <<endl;
		};
		
		void showInfo()
		{
			cout << ".................................." << endl;
			cout << "...........EMPLOYEE INFORMATION....... " << endl;
			cout << "name:.......................... " << this->emp_name << endl;
			cout << "id:............................." << this->emp_id <<  endl;
			cout << "````````````````````````````````" << endl;
		};
		
		
		string emp_name;
	private:
		string emp_id;
		double tax = 0;
		double bounues[3];
		int bonus_top = -1;
		double salary = 0;
		double pay_per_hour = 0;
		double total_hours_worked = 0;
		Report *report;
		double sum_of_bonus = 0;		
		Garbage garb;		
		bool tax_calculated = false;
		bool salary_claculated = false;
		
};


