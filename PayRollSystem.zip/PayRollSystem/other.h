using namespace std;

class Init
{
	Init(int num_of_emp)
	{
		this->number_of_employees = num_of_emp;
		this->all_taxes = new double[this->number_of_employees];
		alert("[+] Payrol initalized successfully", true, true);
	};
	
	void alert(string msg, bool new_line, bool line_brk)
	{
		if(line_brk)
		{
			this->lineBrk();
		};
		
		if(new_line)
		{
			cout << msg << endl;
		}else
		{
			printf("%d", msg.c_str());
		};
	};
	
	void lineBrk()
	{
		cout << "...................." <<endl;
	};	
	
	void addTax()
	{
		double new_taxt = getDouble("[+] Enter the taxt value");
		this->tax_top += 1;
		this->all_taxes[this->tax_top] = new_tax;
		
		alert("[+] The new tax is added", true, true);
	};
	
	double getDouble(string msg)
	{
		double result;
		alert(msg, false, false);
		cin >> result;
		
		return result;
	};
	
	
	private:
		int number_of_employees;
		int tax_top = -1;
		double new_tax;
		double *all_taxes;
};
