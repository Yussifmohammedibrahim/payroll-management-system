#include <iostream>
using namespace std;

class Garbage
{
	public:
		void freeDouble(double *value)
		{
			delete value;
		};
		
		void freeInt(int *value)
		{
			delete value;
		};
		
		void freeString(string *value)
		{
			delete value;
		};
		
		void freeFloat(float *value)
		{
			delete value;
		};
};
