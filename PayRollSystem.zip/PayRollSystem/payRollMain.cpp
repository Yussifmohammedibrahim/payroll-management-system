#include <iostream>
#include "employee.h"
using namespace std;


class Runner
{
	public:
		
		string getString(string msg)
		{
			string value;
			
			printf("%s: ", msg.c_str());
			cin >> value;
			
			return value;
		};
		
		
		int empIndex(string emp_name)
		{
			int slot_index = -1;
				
			for(int i=0; i<=this->slot_top; i++)
			{
				if(emp_name == this->all_emps[i].emp_name)
				{
					this->all_emps[i].showInfo();
					cout << endl;
					
					slot_index = i;
					break;
				};
			};
			
			return slot_index;
		};
		
		void removeEmp()
		{
			int index = -1;
			string *name = new string;		
			
			this->lineBrk();
			*name = this->getString("[+] enter emp* name to remove");
			
			index = this->empIndex(*name);
			if(index >= 0)
			{
				for(int i=index; i<this->slot_top; i++)
				{
					this->all_emps[i] = this->all_emps[i+1];
					
				};
				this->slot_top -= 1;
				cout << "EMP* IS REMOVED" << endl;
			}else
			{
				
				alert("EMP* IS NOT FOUND", true, true);
			};
			
			this->lineBrk();
			delete name;
		};
		
		void findEmp()
		{
			string *emp_name = new string;
			*emp_name = this->getString("[+] Enter emp* name to find");
			
			int *emp_index = new int;
			*emp_index = this->empIndex(*emp_name);
			
			if(*emp_index >= 0)
			{
				int *show_report = new int;;
				
				cout << "[+] EMPLOYEEE IS FOUND" << endl;
				printf("[+] do you want the report for the employee? (0/1): ");
				cin >> *show_report;
				
				if(*show_report == 1)
				{
					this->all_emps[*emp_index].showReport();
					cout << endl;
				};
			}else
			{
				cout << "EMP* IS NOT FOUND" << endl;
			};
			
			cout << endl;
						
			delete emp_index; delete emp_name;
			
		};
		
		
		void addEmp(Emp new_emp)
		{
			if(this->isFull())
			{
				alert("[-] Error: SLOT IS FULL", true, true);
				return;
			}else
			{
				if(this->all_emps)
				{
					this->slot_top += 1;
					this->all_emps[this->slot_top] = new_emp;
					
					this->alert("[+] THE EMPLOYEE IS ADDED", true, true);
					cout << endl;
				}else
				{
					alert("[-] ERROR: PLEASE INITIALIZE BERFORE ADDING EMP", true, true);
				};
			};
			
			
		};
		
		void initRunner(int slot)
		{
			this->emp_size = slot;
			this->all_emps = new Emp[this->emp_size];
			
			string msg = "[+] SLOT SIZE SET";
			this->alert(msg, true, true);
		};
		
		
		void alert(string msg, bool new_line, bool line_brk)
		{
			if(line_brk)
			{
				this->lineBrk();
			};
			
			if(new_line)
			{
				cout << msg << endl;
			}else 
			{
				printf("%S", msg.c_str());
			};
			
			return;
		};
		
		void lineBrk()
		{
			cout << "......................." << endl;
		};
		
		bool isFull()
		{
			if(this->slot_top > -1)
			{
				if(this->slot_top == (this->emp_size-1))
				{
					return 1;
				};
				
				return 0;
			};
			
			return 0;
		};
		
	private:
		Emp *all_emps;
		int emp_size = 0;
		int slot_top = -1;
		
};

void options()
{
	cout << endl;
	
	cout << "0. Close/Exit Program" << endl;
	cout << "1. To add new emp" << endl;
	cout << "2. Find emp*" << endl;
	cout << "3. To remove employee" << endl;
	cout << "4. Generate report " << endl;
//	cout << "5. Set Bonus" << endl;
	cout << endl;
	printf("[+] choose your prefered operation: ");
	
	
};

void runner()
{
	Runner runClass;
	runClass.initRunner(10);
	
	Emp *emp;
	
	int run = 1;
	
	while(run != 0)
	{
		options();
		cin >> run;
		
		switch(run)
		{
			case 1:
				emp = new Emp;
				emp->setInfo();
				runClass.addEmp(*emp);
				break;
			
			case 2:
				runClass.findEmp();
				break;
			
			case 3:
				runClass.removeEmp();
				break;
			
			case 4:
				runClass.findEmp();
				break;
			
			case 5:
				int x = 0;
//				emp->setBonuses();
//				emp->sumAllBonus();
				break;
		};
	}
	
};

int main()
{
	
	runner();
	return 0;
}
