#include <iostream>
using namespace std;

/*
	.....................................
				APP
	.....................................
	-
	.....................................
	+ createnew();
	+ genReport();
	+ setValues();
	+ removeEmp();
	+ findEmp();
	+ 
	.....................................
*/

class application
{
	
	public:
		
		void options()
		{
			cout << endl;
			
			cout << "0. Close/Exit Program" << endl;
			cout << "1. To add new emp" << endl;
			cout << "2. To remove employee" << endl;
			cout << "3. Generate report " << endl;
			
			
		};
		
		
		void luncher()
		{
			do
			{
				int opecode;
				
				this->options();
				alert("choose your operation: ", false, true);
				
				cin>> opecode;
				
				switch(opecoce)
				{
					case 0:
						alert("GOOD BYE", true, true);
						break;
					
					case 1:
						this->createNew();
						break;
					
					case 2:
						this->removeEmp();
						break;
					
					case 3:
						this->genReport();
				};
				
			}while( opecode != 0);
		};
		
		
		void createNew()
		{
			this->stab();
		};
		
		
		void lineBrk()
		{
			cout << "......................" << endl;
		};
		
		void alertMsg(string msg, bool new_line, bool line_brk)
		{
			if(line_brk)
			{
				this->lineBrk();
			};
			
			if(new_line)
			{
				cout << msg << endl;
			};
			
			return;
		};
		
		
		void genReport()
		{
			this->stab();
		};
		
		void removeEmp()
		{
			this->stab();
		};
		
		void findEmp()
		{
			this->stab();
		};
		
		void setValues()
		{
			this->stab();
		};
	
	private:
		int init;
		
		void stab()
		{
			cout << "this method is not completed" << endl;
		};
	
};

